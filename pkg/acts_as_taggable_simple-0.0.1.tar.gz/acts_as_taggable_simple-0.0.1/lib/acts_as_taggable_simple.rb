# ActsAsTaggableSimple

require 'tag'
require 'tagging'
require 'active_record/acts/taggable'
