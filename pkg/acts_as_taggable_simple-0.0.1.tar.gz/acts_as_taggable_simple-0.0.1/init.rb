# Include hook code here

require 'acts_as_taggable_simple'
